//se importa bcrypt

const passport = require('passport');
require('../middlewares/google')


function acerca(req, res) {
    res.render('ac/acerca',  {name: req.session.name})
}
//Es la funcion que redirecciona ala carpeta login y al index y si ya se registro redirecciona a la raiz
function index(req, res) {
  if (req.session.loggedin != true) {
    res.render('login/index');
  }else{
    res.redirect('/')
  }
}

function storeUser(req,res,next){
  passport.authenticate('google', { scope: [ 'email', 'profile' ]})(req,res,next)
}

function callback(req,res,next){
  passport.authenticate( 'google', {
    successRedirect: '/process',
    failureRedirect: '/auth/google/failure'
  })(req,res,next)
}

function fail(req,res){
  res.send('Failed to authenticate..')
}


  







module.exports = {
  index,
  acerca,
  storeUser,
  callback,
  fail,
}