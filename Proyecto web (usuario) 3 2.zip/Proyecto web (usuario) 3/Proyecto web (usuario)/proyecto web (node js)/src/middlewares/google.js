const passport = require('passport')
const GoogleStrategy = require( 'passport-google-oauth2' ).Strategy;


const GOOGLE_CLIENT_ID = '426199424005-0pccavf2i4b0nve1kom2h6345eprtq9v.apps.googleusercontent.com'
const GOOGLE_CLIENT_SECRET= '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'

passport.use(new GoogleStrategy({
    clientID: GOOGLE_CLIENT_ID,
    clientSecret: GOOGLE_CLIENT_SECRET,
    callbackURL: "http://localhost:5000/auth/google",
    passReqToCallback   : true
  },
  function(request, accessToken, refreshToken, profile, done) {
    return done(null, profile);
  }
));

passport.serializeUser(function(user, done) {
    done(null, user);
  });
  
passport.deserializeUser(function(user, done) {
    done(null, user);
  });