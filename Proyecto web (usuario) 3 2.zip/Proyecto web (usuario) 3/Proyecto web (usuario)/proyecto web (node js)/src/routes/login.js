const express = require('express');
const LoginController = require('../controllers/LoginController');
require('../middlewares/google')


const router = express.Router();

///Son las redirecciones para que funcione el sistema

router.get('/acerca', LoginController.acerca);
router.get('/login', LoginController.index);
router.get('/auth/googles', LoginController.storeUser);
router.get('/auth/google', LoginController.callback);
router.get('/auth/google/failure', LoginController.fail)


module.exports = router;